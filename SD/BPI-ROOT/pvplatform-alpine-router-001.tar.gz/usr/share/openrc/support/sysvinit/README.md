Here's a sample inittab for use with sysvinit for Linux based systems.
We don't install it by default as sysvinit packages normally own this file.
